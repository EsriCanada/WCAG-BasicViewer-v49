/// <amd-dependency path="esri/core/tsSupport/declareExtendsHelper" name="__extends" />
/// <amd-dependency path="esri/core/tsSupport/decorateHelper" name="__decorate" />
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
define(["require", "exports", "esri/core/tsSupport/declareExtendsHelper", "esri/core/tsSupport/decorateHelper", "esri/core/accessorSupport/decorators", "esri/widgets/Widget", "dojo/dom-class", "dojo/query", "dojo/on", "dojo/i18n!../nls/resources", "esri/widgets/support/widget"], function (require, exports, __extends, __decorate, decorators_1, Widget, domClass, query, on, i18n, widget_1) {
    "use strict";
    var FeaturesListItem = /** @class */ (function (_super) {
        __extends(FeaturesListItem, _super);
        function FeaturesListItem() {
            var _this = _super.call(this) || this;
            _this._addedLabel = function (element) {
                // this.mapView.when(() =>{
                //     const popupTemplate = this.feature.getEffectivePopupTemplate();
                //     this.feature.popupTemplate = popupTemplate;
                //     this.mapView.popup.features = [this.feature];
                //     setTimeout(() => {
                //         this.Title = this.mapView.popup.title;
                //         console.log("title", this.feature.attributes, this.Title);
                //     }, 50);
                // });
            };
            _this._addedCheckBox = function (element) {
                _this._checkBox = element;
                // const _layerId = this.feature.layer.id;
                // const _featureId = this.feature.attributes[this.feature.objectIdFieldName];
                // this._checkBox.id = `featureButton_${_layerId}_${_featureId}`;
                // this._checkBox.value = this.feature.layer.id+","+this.feature.id;
                _this.own(on(_this._checkBox, "change", _this._featureExpand));
            };
            _this._featureExpand = function (event) {
                _this.__featureExpand(event.target);
            };
            _this.__featureExpand = function (checkBox, restore) {
                if (restore === void 0) { restore = false; }
                if (_this.featureList._prevSelected && !restore) {
                    query('.featureItem_' + _this.featureList._prevSelected).forEach(function (e) {
                        // dojo.removeClass(e, 'showAttr');
                        domClass.add(e, "hideAttr");
                        var li = e.closest('li');
                        domClass.remove(li, "borderLi");
                    });
                    query('#featureButton_' + _this.featureList._prevSelected).forEach(function (e) {
                        e.checked = false;
                    });
                }
                var values = checkBox.value.split(',');
                var r = _this.featureList.tasks.filter(function (t) { return t.layer.id == values[0]; });
                console.log("tasks", values[0], values[1], _this.featureList.tasks, r);
                // const objectIdFieldName = r.layer.objectIdField;
                var fid = values[1];
                var layer = _this.feature.layer; //r[0].layer;
                _this.mapView.graphics.forEach(function (gr) {
                    if (gr.name && gr.name === 'featureMarker') {
                        _this.mapView.graphics.remove(gr);
                    }
                });
                // lang.hitch(this, this.featureList.showBadge(checkBox.checked));
                var li = _this.container;
                domClass.add(li, 'borderLi');
                if (checkBox.checked) {
                    _this._prevSelected = _this.featureList._prevSelected = values[0] + '_' + fid;
                    var featureControls = li.querySelector('.featureControls');
                    domClass.remove(featureControls, 'hideAttr');
                    var featureContent = li.querySelector('.featureContent');
                    domClass.remove(featureContent, 'hideAttr');
                    var featureContentPane = li.querySelector('.featureContentPane');
                    // const q = new Query();
                    // q.where = objectIdFieldName+"="+fid;
                    // q.outFields = layer.fields.map(function(fld) {return fld.name;});//objectIdFieldName];
                    // q.returnGeometry = true;
                    // r.task.execute(q).then(lang.hitch(this, function(ev) {
                    //     const feature = ev.features[0];
                    //     if(!featureContentPane.attributes.hasOwnProperty('widgetid')) {
                    //         const contentPane = new ContentPane({ }, featureContentPane);
                    //         contentPane.startup();
                    //         const myContent = layer.infoTemplate.getContent(feature);
                    //         contentPane.set("content", myContent).then(lang.hitch(this, function() {
                    //             const mainView = featureContentPane.querySelector('.esriViewPopup');
                    //             if(mainView) {
                    //                 domAttr.set(mainView, 'tabindex',0);
                    //                 const mainSection = mainView.querySelector('.mainSection');
                    //                 if(mainSection) {
                    //                     domConstruct.destroy(mainSection.querySelector('.header'));
                    //                 }
                    //                 const attrTables = query('.attrTable', mainSection);
                    //                 if(attrTables && attrTables.length > 0) {
                    //                     for(let i = 0; i<attrTables.length; i++) {
                    //                         const attrTable = attrTables[i];
                    //                         // domAttr.set(attrTable, 'role', 'presentation');
                    //                         const attrNames = query('td.attrName', attrTable);
                    //                         if(attrNames && attrNames.length > 0) {
                    //                             for(let j = 0; j<attrNames.length; j++) {
                    //                                 attrNames[j].outerHTML = attrNames[j].outerHTML.replace(/^<td/, '<th').replace(/td>$/, 'th>');
                    //                             }
                    //                         }
                    //                     }
                    //                 }
                    //                 const images = query('.esriViewPopup img', myContent.domNode);
                    //                 if(images) {
                    //                     images.forEach(function(img) {
                    //                         const alt = domAttr.get(img, 'alt');
                    //                             if(img.src.startsWith('http:') && location.protocol==='https:') {
                    //                             img.src = img.src.replace('http:', 'https:');
                    //                         }
                    //                         if(!alt) {
                    //                             domAttr.set(img,'alt','Attached Image');
                    //                         } else {
                    //                             domAttr.set(img,'tabindex',0);
                    //                             if(!domAttr.get(img, 'title'))
                    //                             {
                    //                                 domAttr.set(img,'title', alt);
                    //                             }
                    //                         }
                    //                     });
                    //                 }
                    //             }
                    //         }));
                    //     }
                    //     li.scrollIntoView({block: "start", inline: "nearest", behavior: "smooth"});
                    //     let markerGeometry = null;
                    //     let marker = null;
                    //     switch (feature.geometry.type) {
                    //         case "point":
                    //             markerGeometry = feature.geometry;
                    //             marker = this.featureList.markerSymbol;
                    //             break;
                    //         case "extent":
                    //             markerGeometry = feature.getCenter();
                    //             break;
                    //         case "polyline" :
                    //             markerGeometry = feature.geometry;
                    //             marker = new CartographicLineSymbol(
                    //                 CartographicLineSymbol.STYLE_SOLID, new Color([0, 127, 255]), 10,
                    //                 CartographicLineSymbol.CAP_ROUND,
                    //                 CartographicLineSymbol.JOIN_ROUND, 5);
                    //             break;
                    //         default:
                    //             // if the feature is a polygon
                    //             markerGeometry = feature.geometry;
                    //             marker = new SimpleFillSymbol(
                    //                 SimpleFillSymbol.STYLE_SOLID,
                    //                 new SimpleLineSymbol(
                    //                     SimpleLineSymbol.STYLE_SOLID,
                    //                     new Color([0, 127, 255]), 3),
                    //                     new Color([0, 127, 255, 0.25]));
                    //             break;
                    //     }
                    //     const gr = new Graphic(markerGeometry, marker);
                    //     gr.name = 'featureMarker';
                    //     layer._map.graphics.add(gr);
                    // }));
                }
                else {
                    domClass.remove(li, 'borderLi');
                    query('.featureItem_' + _this.featureList._prevSelected).forEach(function (e) {
                        domClass.add(e, 'hideAttr');
                    });
                    _this.featureList._prevSelected = null;
                }
            };
            return _this;
        }
        FeaturesListItem.prototype.postInitialize = function () {
            // this.mapView.when(() =>{
            //     const popupTemplate = this.feature.getEffectivePopupTemplate();
            //     this.feature.popupTemplate = popupTemplate;
            //     this.mapView.popup.features = [this.feature];
            //     setTimeout(() => {
            //         this.Title = this.mapView.popup.title;
            //         console.log("title", this.feature.attributes, this.Title);
            //     }, 50);
            // });
        };
        FeaturesListItem.prototype.render = function () {
            // console.log("Render");
            var _title = this.featureWidget.title;
            // // console.log("feature", this.feature, title, this.feature.layer.popupTemplate, this.feature.layer.popupTemplate._getTitleFields(this.feature), this.feature.attributes);
            // let _title = this.feature.layer.popupTemplate.title.mixIn(this.feature.attributes);
            // const _layerId = this.feature.layer.id;
            // const _featureId = this.feature.id;
            var id = "" + this.featureWidget.id;
            console.log("popup", this.mapView.popup);
            // const popupTemplate = this.feature.getEffectivePopupTemplate();
            // this.feature.popupTemplate = popupTemplate;
            // this.mapView.popup.features = [this.feature];
            // setTimeout(() => {
            //     console.log("title", this.mapView.popup.title);
            // }, 20);
            return (widget_1.tsx("div", { class: "featureItem" },
                widget_1.tsx("table", { width: "100%", role: "presentation" },
                    widget_1.tsx("tr", null,
                        widget_1.tsx("th", { valign: "top", rowspan: "3" },
                            widget_1.tsx("input", { class: "checkbox", type: "checkbox", name: "featureItem", afterCreate: this._addedCheckBox })),
                        widget_1.tsx("th", { valign: "top", align: "left", width: "100%" },
                            widget_1.tsx("label", { for: "featureButton_{id}", class: "checkbox", afterCreate: this._addedLabel }, _title))),
                    widget_1.tsx("tr", { class: "featureControls featureItem_{id} hideAttr" },
                        widget_1.tsx("td", null,
                            widget_1.tsx("input", { id: "panBtn_{id}", class: "fc bg pageBtn", type: "button", value: i18n.featureList.panTo, "data-dojo-attach-event": "onclick: featurePan", "data-layerId": "{_layerId}" }),
                            widget_1.tsx("input", { id: "zoomBtn_{id}", class: "fc bg pageBtn", type: "button", value: i18n.featureList.zoomTo, "data-dojo-attach-event": "onclick: featureZoom", "data-layerId": "${_layerId}" }))),
                    widget_1.tsx("tr", { class: "featureContent featureItem_${id} hideAttr" },
                        widget_1.tsx("td", { class: "featureContentPane" })))));
        };
        __decorate([
            decorators_1.property()
        ], FeaturesListItem.prototype, "mapView", void 0);
        __decorate([
            decorators_1.property()
        ], FeaturesListItem.prototype, "feature", void 0);
        __decorate([
            decorators_1.property()
        ], FeaturesListItem.prototype, "featureWidget", void 0);
        __decorate([
            decorators_1.property()
        ], FeaturesListItem.prototype, "featureList", void 0);
        __decorate([
            decorators_1.property()
        ], FeaturesListItem.prototype, "tool", void 0);
        FeaturesListItem = __decorate([
            decorators_1.subclass("esri.widgets.FeaturesListItem")
        ], FeaturesListItem);
        return FeaturesListItem;
    }(decorators_1.declared(Widget)));
    return FeaturesListItem;
});
//# sourceMappingURL=FeaturesListItem.js.map